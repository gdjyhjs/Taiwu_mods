﻿using System.IO;
using UnityEditor;

public class CreateAssetsBundle
{
    //创建编辑器菜单目录
    [MenuItem("制作资源/制作蛐蛐冒险UI资源")]
    static void BuildABs()
    {
        //将这些资源包放在一个名为ABs的目录下
        string assetBundleDirectory = "Assets/Abs";
        //如果目录不存在，就创建一个目录
        if (!Directory.Exists(assetBundleDirectory))
        {
            Directory.CreateDirectory(assetBundleDirectory);
        }
        BuildPipeline.BuildAssetBundles(assetBundleDirectory, BuildAssetBundleOptions.None, BuildTarget.StandaloneWindows);
    }
}